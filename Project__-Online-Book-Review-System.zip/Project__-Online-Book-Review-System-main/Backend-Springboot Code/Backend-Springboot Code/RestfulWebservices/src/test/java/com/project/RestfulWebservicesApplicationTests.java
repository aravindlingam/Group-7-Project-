package com.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}
@Test
void getId() {
	System.out.println("test case");
}
}
